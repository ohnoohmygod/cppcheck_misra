

typedef	struct _tGames
{
    char magicdirname[10];
    unsigned int expectedmask;
    unsigned char pictureorder[3];
} tGames;

static const tGames games[1]={
    {"Pawn", 1, {0,1,2}}
};





