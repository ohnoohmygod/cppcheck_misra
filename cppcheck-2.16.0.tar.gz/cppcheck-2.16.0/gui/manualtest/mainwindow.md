
# Main window

Some manual testing in the main window interface


## Test: Recheck file

1. Load a project with results.
1. Restart the GUI.
1. Right click on a file and click on "Recheck".

EXPECTED: Results for that file should be refreshed.


## Test: Switch project

1. Open project #1
1. Open project #2 that has different results

EXPECTED: Results for project #1 should go away, results for project #2 should be shown
